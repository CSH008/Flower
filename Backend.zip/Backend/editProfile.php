<?php 
require 'conn.php';
$data = $_REQUEST;
$user_id = $data['user_id'];
$password = $data['password'];
$new_password = $data['new_password'];
$mobile_number = $data['mobile_number'];
$first_name = $data['first_name'];
$last_name = $data['last_name'];
$national_id = $data['national_id'];
$dob = $data['dob'];

$sql="SELECT * FROM user WHERE user_id='".$user_id."' AND password = '".sha1($password)."'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
	if($new_password=='')
		$query = "UPDATE user SET `mobile_number`='".$mobile_number."',`first_name`='".$first_name."',`last_name`='".$last_name."',`national_id`='".$national_id."',`dob`='".$dob."',`updated_at`='".date('Y-m-d H:i:s')."' WHERE user_id='".$user_id."'";	
	else
		$query = "UPDATE user SET `password`='".sha1($new_password)."',`mobile_number`='".$mobile_number."',`first_name`='".$first_name."',`last_name`='".$last_name."',`national_id`='".$national_id."',`dob`='".$dob."',`updated_at`='".date('Y-m-d H:i:s')."' WHERE user_id='".$user_id."'";	
	$data1 = mysqli_query($con, $query);
	if($data1) {
		$response['res'] = sha1("User details are updated successfuly");
    	$response['result'] = true;  		
    }  else {
		$response['res'] = sha1("User details incorrect. Please try again");
    	$response['result'] = false;    	
    }  
    echo json_encode($response);
} else {
	$response['res'] = sha1("User details incorrect. Please try again");
    $response['result'] = false;
	echo json_encode($response);
}

mysqli_close($con);
?>