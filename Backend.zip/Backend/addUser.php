<?php 
require 'conn.php';
$data = $_REQUEST;
$user_id = $data['user_id'];
$password = $data['password'];
echo $user_id;
$sql="INSERT INTO user (user_id,password,created_at) VALUES ('".$user_id."','".sha1($password)."','".date('Y-m-d H:i:s')."')";
$result = mysqli_query($con,$sql);
$insert_id = mysqli_insert_id($con);
echo $result;
mysqli_close($con);
?>