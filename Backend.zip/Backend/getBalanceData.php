<?php
$collector_id= $_REQUEST['collector_id'];
$meter_id = $_REQUEST['meter_id'];
require 'conn.php';
$sql="SELECT * FROM balance WHERE collector_ID = '$collector_id' AND meter_ID='$meter_id'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
    // output data of each row
    $response['result'] = true;
    $response['res'] = sha1("Success");    
    while($row = mysqli_fetch_array($result)) {
    	$response['oldbalance_limit']=$row['oldbalance_limit'];
        $response['newbalance_limit']=$row['newbalance_limit'];
 	}
	echo json_encode($response);       
} else {
    $response['result'] = true;
    $response['res'] = sha1("Fail");
   	$response['oldbalance_limit']='0';
    $response['newbalance_limit']='0';
    echo json_encode($response);      
}
mysqli_close($con);
?>