
<?php
$test = @$_GET['ll'];
$collector_id= $_POST['colid'];
$meter_id = $_POST['meterid'];
if($test == "secrt"){ 
require 'conn.php';
  $sql="SELECT * FROM main_info WHERE date >= CURDATE() + INTERVAL -30 DAY AND collector_ID = '$collector_id' AND meter_ID='$meter_id'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
    // output data of each row
    while($row = mysqli_fetch_array($result)) {
        $flag[]=$row;
 }
 echo json_encode($flag);       
} else {
    echo "0 results";
}
mysqli_close($con);
}
else{
    echo("not found");
}
?>