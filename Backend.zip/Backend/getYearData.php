<?php
$test = $_REQUEST['ll'];
$collector_id= $_REQUEST['collector_id'];
$meter_id = $_REQUEST['meter_id'];
if($test == "secrt"){ 
require 'conn.php';
  $sql="SELECT * FROM main_info WHERE date >= CURDATE() + INTERVAL -365 DAY AND collector_ID = '$collector_id' AND meter_ID='$meter_id'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
    // output data of each row
    $response['result'] = true;
    $response['res'] = sha1("Success");    
    while($row = mysqli_fetch_array($result)) {
    	$response['dates'][]=$row['date'];
        $response['r_meters'][]=$row['r_meter'];
 	}
	 echo json_encode($response);       
} else {
    $response['result'] = false;
    $response['res'] = sha1("Fail");
    echo json_encode($response);      
}
mysqli_close($con);
}
else{
    $response['result'] = false;
    $response['res'] = sha1("Not Found");
    echo json_encode($response);   
}
?>