<?php 
require 'conn.php';
$data = $_REQUEST;
$user_id = $data['user_id'];
$password = $data['password'];
$sql="SELECT * FROM user WHERE user_id='".$user_id."' AND password = '".sha1($password)."'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
  while($row = mysqli_fetch_array($result)) {
        $flag[]=$row;
        $response['result'] = true;
        $response['res'] = sha1("Successful Login");
        $response['id'] = $row['id'];
        $response['mobile_number'] = $row['mobile_number'];
        $response['first_name'] = $row['first_name'];
        $response['last_name'] = $row['last_name'];
        $response['national_id'] = $row['national_id'];
        $response['dob'] = $row['dob'];
 }
 echo json_encode($response);       
} else {
	$response['res'] = sha1("Login details incorrect. Please try again");
    $response['result'] = false;
    $response['mobile_number'] = $user_id;
    $response['first_name'] = $password;
	echo json_encode($response);
}

mysqli_close($con);
?>