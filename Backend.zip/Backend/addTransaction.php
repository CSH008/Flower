<?php 
require 'conn.php';
$data = $_REQUEST;
$transaction_id = $data['transaction_id'];
$payment_value = $data['payment_value'];
$credit = $data['credit'];
$payer_id = $data['payer_id'];
$collector_id = $data['collector_id'];
$meter_id = $data['meter_id'];
$payment_method = $data['payment_method'];

$query = "INSERT INTO transaction (transaction_id,payment_value,credit,payer_id,collector_id,meter_id,payment_method,transaction_date) VALUES ('".$transaction_id."','".$payment_value."','".$credit."','".$payer_id."','".$collector_id."','".$meter_id."','".$payment_method."','".date('Y-m-d H:i:s')."' )";
//$query = "INSERT INTO transaction (payment_value,credit,payer_id,collector_id,meter_id,payment_method,transaction_date) VALUES ('".$payment_value."','".$credit."','".$payer_id."','".$collector_id."','".$meter_id."','".$payment_method."','".date('Y-m-d H:i:s')."' )";

$result = mysqli_query($con,$query);
$insert_id = mysqli_insert_id($con);

if ($insert_id){
	$response['res'] = "success";
    $response['result'] = true; 
 	echo json_encode($response);       
} else {
	$response['res'] = "failed";
    $response['result'] = false;
	echo json_encode($response);
}

mysqli_close($con);
?>