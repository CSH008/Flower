<?php 
require 'conn.php';

$data = $_REQUEST;
$user_id = $data['user_id'];
 
$sql="SELECT * FROM mcoll_info where user_id='".$user_id."'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
    // output data of each row
    $response['result'] = true;
    $response['res'] = sha1("Success");
    while($row = mysqli_fetch_array($result)) {
        $response['collectors'][]=$row['mcoll_id'];
 	} 	
 	echo json_encode($response);       
} else {
 	$response['result'] = false;
    $response['res'] = sha1("Fail");
    echo json_encode($response);       
}
mysqli_close($con);
?>