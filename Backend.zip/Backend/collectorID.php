<?php 
require 'conn.php';
  $sql="SELECT * FROM mcoll_info";
  //$sql = "SELECT * FROM collector_info";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
    // output data of each row
    while($row = mysqli_fetch_array($result)) {
        $flag[]=$row;
 }
 echo json_encode($flag);       
} else {
    echo "0 results";
}
mysqli_close($con);
?>