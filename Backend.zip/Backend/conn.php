<?php
$host = "108.166.181.6"; 
$user = "root";
$pass = "BestTe@m1";
$db = "flower";
$port = 3306;
$con=mysqli_connect($host,$user,$pass,$db,$port);
 if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>