<?php 
require 'conn.php';
$data = $_REQUEST;
$collector_id = $data['collector_id'];
$meter_id = $data['meter_id'];
$oldbalance_limit = $data['oldbalance_limit'];
$newbalance_limit = $data['newbalance_limit'];
$purchase_user_id = $data['purchase_user_id'];

$sql="SELECT * FROM balance WHERE collector_id = '".$collector_id."' AND meter_id='".$meter_id."'";
$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
	$query = "UPDATE user SET oldbalance_limit='$oldbalance_limit',newbalance_limit='$newbalance_limit',purchase_user_id='$purchase_user_id',purchase_updated_date='".date('Y-m-d H:i:s')."' WHERE collector_id='$collector_id' AND meter_id='$meter_id'";
	$data1 = mysqli_query($con, $query);
	if($data1) {
		$response['res'] = sha1("success");
    	$response['result'] = true;  		
    }  else {
		$response['res'] = sha1("fail");
    	$response['result'] = false;    	
    }  
    echo json_encode($response);	 
} else {
	$query = "INSERT INTO balance (collector_id,meter_id,oldbalance_limit,newbalance_limit,purchase_user_id,purchase_created_date,purchase_updated_date) VALUES ('".$collector_id."','".$meter_id."','".$oldbalance_limit."','".$newbalance_limit."','".$purchase_user_id."','".date('Y-m-d H:i:s')."','".date('Y-m-d H:i:s')."')";
	$result = mysqli_query($con,$query);
	$insert_id = mysqli_insert_id($con);
	if ($insert_id){
		$response['res'] = sha1("success");
	    $response['result'] = true; 
		echo json_encode($response);       
	} else {
		$response['res'] = sha1("fail");
	    $response['result'] = false;
		echo json_encode($response);
	}
}
mysqli_close($con);
?>