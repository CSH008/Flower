<?php 
require 'conn.php';
$data = $_REQUEST;
$user_id = $data['user_id'];
$collector_id = $data['collector_id'];
$meter_id = $data['meter_id'];
$longitude = $data['longitude'];
$latitude = $data['latitude'];

$sql="SELECT * FROM meter_info WHERE meter_id = '".$meter_id."' AND user_id='".$user_id."'";
$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
} else {
	$query = "INSERT INTO meter_info (meter_id,user_id) VALUES ('".$meter_id."','".$user_id."')";
	$result = mysqli_query($con,$query);
	$insert_id = mysqli_insert_id($con);
	if ($insert_id){		
	} else {
		$response['res'] = sha1("Fail");
	    $response['result'] = false;
		echo json_encode($response);
		mysqli_close($con);
		return;
	}	
}


$sql="SELECT * FROM mcoll_info WHERE mcoll_id = '".$collector_id."' AND user_id='".$user_id."'";
$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
} else {
	$query = "INSERT INTO mcoll_info (mcoll_id,user_id) VALUES ('".$collector_id."','".$user_id."')";
	$result = mysqli_query($con,$query);
	$insert_id = mysqli_insert_id($con);
	if ($insert_id){		
	} else {
		$response['res'] = sha1("Fail");
	    $response['result'] = false;
		echo json_encode($response);
		mysqli_close($con);
		return;
	}

}

$sql="SELECT * FROM meter WHERE collector_id = '".$collector_id."' AND meter_id='".$meter_id."'";

$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result)>0){
	$response['res'] = sha1("success");
    $response['result'] = true; 
	echo json_encode($response);
} else {
	$query = "INSERT INTO meter (collector_id,meter_id,longitude,latitude,user_id,created_at) VALUES ('".$collector_id."','".$meter_id."','".$longitude."','".$latitude."','".$user_id."','".date('Y-m-d H:i:s')."')";

	$result = mysqli_query($con,$query);
	$insert_id = mysqli_insert_id($con);

	if ($insert_id){		
		$response['res'] = sha1("Success");
	    $response['result'] = true; 
		echo json_encode($response);       
	} else {
		$response['res'] = sha1("Fail");
	    $response['result'] = false;
		echo json_encode($response);
	}
}
mysqli_close($con);
?>